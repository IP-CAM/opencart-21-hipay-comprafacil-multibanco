<?php
// Text
$_['text_title'] = 'Multibanco Reference';
$_['text_terms'] = 'Pay at ATM machines or HomeBanking';
?>