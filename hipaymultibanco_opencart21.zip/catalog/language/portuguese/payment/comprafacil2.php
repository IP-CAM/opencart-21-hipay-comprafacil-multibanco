<?php
// Text
$_['text_title'] = 'Multibanco';
$_['text_terms'] = 'Pagamento de Referências Multibanco em ATM ou HomeBanking';
?>