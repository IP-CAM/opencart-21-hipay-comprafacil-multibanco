<?php
echo 'teste2';
require_once('ws2.php');
echo 'teste22';
?>
